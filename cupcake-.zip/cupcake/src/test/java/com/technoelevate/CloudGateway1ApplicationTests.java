package com.technoelevate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGateway1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
