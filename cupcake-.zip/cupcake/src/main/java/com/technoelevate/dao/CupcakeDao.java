package com.technoelevate.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.technoelevate.dto.CupCake;

@Repository
public interface CupcakeDao extends JpaRepository<CupCake, Integer>{

	public CupCake findByCupcake(String cupcake) ;

	public CupCake deleteByCupcake(String cupcake);
	

}
